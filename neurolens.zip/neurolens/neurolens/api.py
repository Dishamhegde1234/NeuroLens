"""JSON API (Flask blueprint)."""
from __future__ import annotations

import re
import secrets
import time
from functools import wraps

from flask import Blueprint, current_app, g, jsonify, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from . import ai_helper, db

bp = Blueprint("api", __name__, url_prefix="/api")

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MAX_FAILS, WINDOW = 5, 300  # 5 failures per 5 minutes (in-memory, per server process)


def svc():
    return current_app.extensions["neurolens"]


def error(message: str, status: int):
    return jsonify({"error": message}), status


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        uid = session.get("uid")
        user = db.get_user(uid) if uid else None
        if not user:
            session.clear()
            return error("Please sign in.", 401)
        g.user = user
        return view(*args, **kwargs)
    return wrapped


def _fails() -> dict:
    """(ip, email) -> failure timestamps. Lives on the app so tests stay isolated."""
    return current_app.extensions.setdefault("login_fails", {})


def _throttled(key) -> bool:
    now = time.time()
    fails = _fails()
    fails[key] = [t for t in fails.get(key, []) if now - t < WINDOW]
    return len(fails[key]) >= MAX_FAILS


def _start_session(uid: int) -> None:
    session.clear()
    session.permanent = True
    session["uid"] = uid


# ------------------------------------------------------------------- auth
@bp.post("/signup")
def signup():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    if not name or len(name) > 60:
        return error("Enter your name (up to 60 characters).", 400)
    if not EMAIL_RE.match(email) or len(email) > 120:
        return error("Enter a valid email address, like name@college.edu.", 400)
    if len(password) < 8 or len(password) > 128:
        return error("Use a password with at least 8 characters.", 400)
    if db.get_user_by_email(email):
        return error("An account with this email exists. Log in instead.", 409)
    uid = db.create_user(name, email, generate_password_hash(password))
    _start_session(uid)
    return jsonify({"ok": True}), 201


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    key = (request.remote_addr, email)
    if _throttled(key):
        return error("Too many attempts. Try again in a few minutes.", 429)
    user = db.get_user_by_email(email)
    if not user or user["is_demo"] or not check_password_hash(user["password_hash"], password):
        _fails().setdefault(key, []).append(time.time())
        return error("Email or password is incorrect.", 401)
    _fails().pop(key, None)
    _start_session(user["id"])
    return jsonify({"ok": True})


@bp.post("/demo")
def demo():
    uid = svc().create_demo_user(secrets.token_hex(6))
    _start_session(uid)
    return jsonify({"ok": True})


@bp.post("/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@bp.get("/me")
@login_required
def me():
    return jsonify({"name": g.user["name"], "demo": bool(g.user["is_demo"])})


# -------------------------------------------------------------- learning data
@bp.get("/dashboard")
@login_required
def dashboard():
    return jsonify(svc().dashboard(g.user))


@bp.get("/topic/<key>")
@login_required
def topic(key):
    detail = svc().topic_detail(g.user, key)
    return jsonify(detail) if detail else error("Unknown topic.", 404)


@bp.get("/question")
@login_required
def question():
    q = svc().next_question(g.user, topic=request.args.get("topic"), level=request.args.get("level"))
    return jsonify(q) if q else error("No question available.", 404)


@bp.post("/answer")
@login_required
def answer():
    data = request.get_json(silent=True) or {}
    qid, choice = data.get("qid"), data.get("choice")
    if not isinstance(qid, str) or not isinstance(choice, int) or isinstance(choice, bool) or not 0 <= choice <= 3:
        return error("Send a question id and a choice from 0 to 3.", 400)
    result = svc().record_answer(g.user, qid, choice)
    return jsonify(result) if result else error("Unknown question.", 404)


@bp.post("/explain")
@login_required
def explain():
    if not ai_helper.available():
        return error("AI explanations are not configured on this server.", 503)
    data = request.get_json(silent=True) or {}
    q = svc().bank.by_id.get(data.get("qid"))
    choice = data.get("choice")
    if not q or not isinstance(choice, int) or isinstance(choice, bool) or not 0 <= choice <= 3:
        return error("Send a valid question id and choice.", 400)
    try:
        text = ai_helper.explain(svc().topics[q["topic"]]["name"], q, choice)
    except ai_helper.AIError as exc:
        return error(str(exc), 502)
    return jsonify({"explanation": text})
