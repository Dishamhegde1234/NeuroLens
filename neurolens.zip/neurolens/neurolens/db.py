"""SQLite access layer.

All SQL lives in this file. To move to Supabase (Postgres), reimplement these
functions against a Postgres driver and keep the rest of the app unchanged;
``supabase_schema.sql`` has the matching table definitions.
"""
from __future__ import annotations

import os
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    base_attendance REAL,                 -- NULL for real users (computed from activity)
    base_hours      REAL NOT NULL DEFAULT 0,
    is_demo         INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    topic       TEXT NOT NULL,
    qid         TEXT,                     -- NULL for seeded demo history
    difficulty  INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 3),
    correct     INTEGER NOT NULL CHECK (correct IN (0, 1)),
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_attempts_user ON attempts (user_id, id);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect(path: str) -> sqlite3.Connection:
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(_exc=None) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db() -> None:
    get_db().executescript(SCHEMA)
    get_db().commit()


# ------------------------------------------------------------------ users
def create_user(name, email, password_hash, *, base_attendance=None, base_hours=0.0,
                is_demo=False, created_at=None) -> int:
    cur = get_db().execute(
        "INSERT INTO users (name, email, password_hash, base_attendance, base_hours, is_demo, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, ?)",
        (name, email, password_hash, base_attendance, base_hours, int(is_demo), created_at or now_iso()),
    )
    get_db().commit()
    return cur.lastrowid


def get_user(user_id: int) -> Optional[sqlite3.Row]:
    return get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def get_user_by_email(email: str) -> Optional[sqlite3.Row]:
    return get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()


def delete_old_demo_users(hours: int = 24) -> None:
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(timespec="seconds")
    get_db().execute("DELETE FROM users WHERE is_demo = 1 AND created_at < ?", (cutoff,))
    get_db().commit()


# ---------------------------------------------------------------- attempts
def add_attempt(user_id, topic, qid, difficulty, correct, created_at=None) -> None:
    get_db().execute(
        "INSERT INTO attempts (user_id, topic, qid, difficulty, correct, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, topic, qid, difficulty, int(correct), created_at or now_iso()),
    )
    get_db().commit()


def user_attempts(user_id: int) -> List[sqlite3.Row]:
    return get_db().execute(
        "SELECT topic, qid, difficulty, correct, created_at FROM attempts WHERE user_id = ? ORDER BY id",
        (user_id,),
    ).fetchall()
