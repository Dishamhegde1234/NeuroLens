"""Explainable, difficulty-aware topic risk.

An *attempt* is a ``(difficulty, correct)`` pair, oldest first, where
``difficulty`` is 1 (easy), 2 (medium) or 3 (hard) and ``correct`` is 0 or 1.

risk = 0.60 * weighted miss rate      (recent answers count more; missing an
                                       easy question counts more than a hard one)
     + 0.25 * recurrence              (misses in the last 5 answers)
     + 0.15 * worsening trend         (second half worse than first half)
     + attendance bump                (small, only when attendance is low)

The miss rate is smoothed toward a neutral prior, so a single answer never
decides the result, and ``confidence`` tells the UI how much data backs it.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

Attempt = Tuple[int, int]

DIFFICULTY_WEIGHT = {1: 1.3, 2: 1.0, 3: 0.7}
DECAY = 0.85
PRIOR_RATE = 0.4
PRIOR_STRENGTH = 2.0
HIGH, MEDIUM = 0.55, 0.38
LOW_ATTENDANCE = 75
ATTENDANCE_BUMP = 0.04
MASTERY_MIN_ATTEMPTS = 4


@dataclass
class TopicRisk:
    risk: float
    n: int
    correct: int
    confidence: float
    weighted_miss: float
    last5: int
    trend: float
    baseline: bool
    missed_easy: bool

    @property
    def tier(self) -> str:
        return tier(self.risk)

    @property
    def mastered(self) -> bool:
        return self.n >= MASTERY_MIN_ATTEMPTS and self.risk < MEDIUM


def tier(risk: float) -> str:
    """'hi', 'mid' or 'lo'."""
    return "hi" if risk >= HIGH else "mid" if risk >= MEDIUM else "lo"


def _weighted_miss(attempts: Sequence[Attempt]) -> float:
    n = len(attempts)
    num = den = 0.0
    for i, (d, c) in enumerate(attempts):
        w = (DECAY ** (n - 1 - i)) * DIFFICULTY_WEIGHT[d]
        num += w * (1 - c)
        den += w
    return (num + PRIOR_RATE * PRIOR_STRENGTH) / (den + PRIOR_STRENGTH)


def _trend(attempts: Sequence[Attempt]) -> float:
    n = len(attempts)
    if n < 4:
        return 0.0
    half = n // 2

    def miss_rate(part):
        return sum(1 for _, c in part if not c) / len(part)

    return max(0.0, miss_rate(attempts[half:]) - miss_rate(attempts[:half]))


def compute_topic_risk(
    attempts: Sequence[Attempt], attendance: Optional[float] = None
) -> TopicRisk:
    n = len(attempts)
    if n == 0:
        return TopicRisk(PRIOR_RATE, 0, 0, 0.0, PRIOR_RATE, 0, 0.0, True, False)

    wmiss = _weighted_miss(attempts)
    last5 = sum(1 for _, c in attempts[-5:] if not c)
    recurrence = min(1.0, last5 / 3)
    trend = _trend(attempts)
    bump = ATTENDANCE_BUMP if (attendance is not None and attendance < LOW_ATTENDANCE) else 0.0
    risk = min(1.0, 0.6 * wmiss + 0.25 * recurrence + 0.15 * trend + bump)
    return TopicRisk(
        risk=risk,
        n=n,
        correct=sum(1 for _, c in attempts if c),
        confidence=n / (n + 4),
        weighted_miss=wmiss,
        last5=last5,
        trend=trend,
        baseline=False,
        missed_easy=any(d == 1 and not c for d, c in attempts),
    )


# ---------------------------------------------------------------- ML (optional)
FEATURE_NAMES = ["n", "accuracy", "weighted_miss", "last5", "trend", "easy_miss_rate", "hard_hit_rate"]


def features(attempts: Sequence[Attempt]) -> list:
    """Feature vector shared by training (train_model.py) and serving."""
    n = len(attempts)
    easy = [c for d, c in attempts if d == 1]
    hard = [c for d, c in attempts if d == 3]
    return [
        float(n),
        sum(c for _, c in attempts) / n if n else 0.0,
        _weighted_miss(attempts) if n else PRIOR_RATE,
        float(sum(1 for _, c in attempts[-5:] if not c)),
        _trend(attempts),
        (1 - sum(easy) / len(easy)) if easy else 0.0,
        (sum(hard) / len(hard)) if hard else 0.0,
    ]


class MissModel:
    """Wraps the scikit-learn model that predicts P(next answer is wrong)."""

    def __init__(self, path: str):
        self.model = None
        if path and os.path.exists(path):
            import joblib  # imported lazily so the heuristic engine needs no ML stack

            self.model = joblib.load(path)

    @property
    def available(self) -> bool:
        return self.model is not None

    def predict_miss(self, attempts: Sequence[Attempt]) -> float:
        return float(self.model.predict_proba([features(attempts)])[0][1])
