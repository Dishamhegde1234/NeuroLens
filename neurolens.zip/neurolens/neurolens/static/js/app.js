/* NeuroLens frontend. Talks to the Flask JSON API; all scoring happens on the server. */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const TIER_LABEL = { hi: 'High', mid: 'Medium', lo: 'Low' };

  let D = null;          // latest /api/dashboard payload
  let sel = null;        // selected topic key
  let assess = null;     // level id while a Proficiency Assessment is running
  let q = null;          // current question
  let view = 'home';
  let mode = 'up';       // auth form mode: 'up' (sign up) or 'in' (log in)
  const openG = {};      // level id -> expanded?

  // ---------------------------------------------------------------- helpers
  async function api(path, opts = {}) {
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data = {};
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (!res.ok) {
      const err = new Error(data.error || 'Something went wrong. Please try again.');
      err.status = res.status;
      throw err;
    }
    return data;
  }

  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage blocked */ } },
  };

  const topicIndex = () => {
    const m = {};
    D.levels.forEach((l) => l.topics.forEach((t) => { m[t.key] = { ...t, levelId: l.id, levelName: l.name }; }));
    return m;
  };
  const fmtHours = (h) => (h < 1 ? Math.round(h * 60 * 10) / 10 + ' min' : h.toFixed(1) + ' h');
  const allTopics = () => D.levels.flatMap((l) => l.topics);

  // ------------------------------------------------------------------ theme
  function applyTheme(t) {
    if (t) document.documentElement.setAttribute('data-theme', t);
    const dark = t ? t === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
    $('th-l').setAttribute('aria-pressed', String(!dark));
    $('th-d').setAttribute('aria-pressed', String(dark));
  }
  $('th-l').onclick = () => { store.set('nl_theme', 'light'); applyTheme('light'); };
  $('th-d').onclick = () => { store.set('nl_theme', 'dark'); applyTheme('dark'); };
  applyTheme(store.get('nl_theme'));

  // ---------------------------------------------------------- menu (mobile)
  function menuToggle(force) {
    const open = force === undefined ? !$('side').classList.contains('open') : force;
    document.documentElement.style.setProperty('--th', document.querySelector('.top').offsetHeight + 'px');
    $('side').classList.toggle('open', open);
    $('scrim').classList.toggle('open', open);
    $('menu').setAttribute('aria-expanded', String(open));
  }
  $('menu').onclick = () => menuToggle();
  $('scrim').onclick = () => menuToggle(false);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') menuToggle(false); });

  // ------------------------------------------------------------------- views
  function go(v) {
    view = v;
    ['home', 'practice', 'plan'].forEach((k) => { $('v-' + k).hidden = k !== v; });
    document.querySelectorAll('.nv[data-v]').forEach((b) => {
      if (b.dataset.v === v) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    menuToggle(false);
    if (v === 'practice') { if (q) renderQuestion(); else loadQuestion(); }
    renderTree();
    window.scrollTo(0, 0);
  }

  function selectTopic(key, { practice = false } = {}) {
    assess = null; sel = key; q = null;
    renderBoard(); renderTree(); loadWhy();
    if (practice) go('practice');
  }

  // ---------------------------------------------------------------- dashboard
  function renderStats() {
    const s = D.stats, T = topicIndex();
    $('xpc').hidden = false;
    $('xpc').textContent = '⭐ ' + s.xp + ' XP';
    const cards = [
      ['Overall progress', Math.round(100 * s.mastered / s.total_topics) + '%', s.mastered + '/' + s.total_topics + ' topics mastered', '📈', 'lo'],
      ['Current level', 'Level ' + s.level, 'Focus: ' + T[s.focus].name, '🚀', 'ac'],
      ['Quiz performance', s.accuracy + '%', 'Best streak ' + s.best_streak + ' | ' + s.attempts + ' attempts', '📝', 'mid'],
      ['Total XP', s.xp, (100 - (s.xp % 100)) + ' XP to level ' + (s.level + 1), '🔥', 'hi'],
    ];
    $('stats').innerHTML = cards.map((c) =>
      `<div class="card stat"><span class="l">${esc(c[0])}</span><b class="d">${esc(c[1])}</b>` +
      `<span class="s" style="color:var(--${c[4]})">${esc(c[2])}</span>` +
      `<span class="ic" style="background:color-mix(in srgb,var(--${c[4]}) 18%,var(--card))">${c[3]}</span></div>`).join('');

    const h = D.habits;
    $('habits').innerHTML =
      `<div class="sub">Attendance</div><div class="row" style="grid-template-columns:1fr 48px;cursor:default">` +
      `<span class="bar"><i style="width:${h.attendance}%;background:var(--lo)"></i></span><span class="pct">${h.attendance}%</span></div>` +
      `<div class="sub">Study hours (goal 10 h)</div><div class="row" style="grid-template-columns:1fr 70px;cursor:default">` +
      `<span class="bar"><i style="width:${Math.min(100, h.hours * 10)}%;background:var(--ac)"></i></span><span class="pct">${fmtHours(h.hours)}</span></div>` +
      `<div class="legend">Both start at 0 for new accounts. Every answer adds study time and each day you practise counts toward attendance.` +
      `${h.attendance < 75 && s.attempts ? ' Attendance under 75% adds a small risk bump.' : ''}</div>`;

    const names = ['Easy', 'Medium', 'Hard'];
    $('dchart').innerHTML = '<div class="cols">' + D.difficulty.map((x) =>
      `<div class="col"><b>${x.n ? x.pct + '%' : '–'}</b><i style="height:${x.pct * 0.9}px"></i>${names[x.d - 1]}<div class="sub">${x.n} tried</div></div>`).join('') + '</div>';

    $('badges').innerHTML = D.badges.map((b) =>
      `<div class="bd ${b.earned ? '' : 'off'}"><div class="e">${b.icon}</div><b>${esc(b.title)}</b><small>${esc(b.desc)}</small></div>`).join('');
  }

  function levelBlock(l, rowClass, rowAttr, withCount) {
    const o = openG[l.id];
    const rows = l.topics.map((t) =>
      `<button class="sn" ${rowAttr(t)} data-t="${t.key}" type="button"><span class="gl">${esc(t.glyph)}</span>` +
      `<span>${esc(t.name)}</span><span class="dotr" style="background:var(--${t.tier})"></span></button>`).join('');
    return `<button class="nv grp" data-g="${l.id}" aria-expanded="${o}" type="button"><span class="gl">${esc(l.icon)}</span><span>${esc(l.name)}</span>` +
      (withCount ? `<span class="cnt">${l.topics.length} topics</span>` : '') + `<span class="chev"></span></button>` +
      `<div class="sb" ${o ? '' : 'hidden'}>${rows}${rowClass === 'tree' ? assessRow(l) : ''}</div>`;
  }
  const assessRow = (l) =>
    `<button class="sn" data-a="${l.id}" ${assess === l.id && view === 'practice' ? 'aria-current="true"' : ''} type="button">` +
    `<span class="gl">🏅</span><span>Proficiency Assessment</span></button>`;

  function renderBoard() {
    $('board').innerHTML = D.levels.map((l) =>
      levelBlock(l, 'board', (t) => `aria-pressed="${t.key === sel}"`, true)).join('');
    $('board').querySelectorAll('.grp').forEach((b) => { b.onclick = () => { openG[b.dataset.g] = !openG[b.dataset.g]; renderBoard(); renderTree(); }; });
    $('board').querySelectorAll('.sn').forEach((b) => { b.onclick = () => selectTopic(b.dataset.t); });
  }

  function renderTree() {
    $('tl').innerHTML = D.levels.map((l) =>
      levelBlock(l, 'tree', (t) => (t.key === sel && view === 'practice' && !assess ? 'aria-current="true"' : ''), false)).join('');
    $('tl').querySelectorAll('.grp').forEach((b) => { b.onclick = () => { openG[b.dataset.g] = !openG[b.dataset.g]; renderBoard(); renderTree(); }; });
    $('tl').querySelectorAll('.sn[data-t]').forEach((b) => { b.onclick = () => selectTopic(b.dataset.t, { practice: true }); });
    $('tl').querySelectorAll('.sn[data-a]').forEach((b) => { b.onclick = () => { assess = b.dataset.a; q = null; go('practice'); }; });
  }

  function renderPlan() {
    const list = allTopics().filter((t) => t.risk >= 0.38).sort((a, b) => b.risk - a.risk).slice(0, 3);
    $('plan').innerHTML = list.length ? list.map((t) => {
      const n = Math.max(4, Math.ceil(t.risk * 10));
      const note = t.n < 4 ? 'Low confidence, so a few attempts will sharpen this.' : t.last5 >= 3 ? 'Repeated misses recently.' : 'Mixed results.';
      return `<li><b>${esc(t.name)}</b>: ${n} questions, start at ${t.missed_easy ? 'easy' : 'medium'} level. ${note}</li>`;
    }).join('') : '<li>No topic is at risk right now. Keep up a light mixed review.</li>';
  }

  async function loadWhy() {
    if (!sel) return;
    try {
      const w = await api('/api/topic/' + encodeURIComponent(sel));
      const dots = w.attempts.map(([d, c]) =>
        `<span class="dot" title="${c ? 'correct' : 'missed'}, difficulty ${d}" style="width:${8 + d * 4}px;height:${8 + d * 4}px;background:${c ? 'var(--lo)' : 'var(--hi)'}"></span>`).join('')
        || '<span class="sub">No attempts yet.</span>';
      $('why').innerHTML =
        `<h2>${esc(w.name)} <span class="tag ${w.tier}">${TIER_LABEL[w.tier]} risk</span></h2>` +
        `<div class="sub">Attempts, oldest to newest. Bigger dot = harder question.</div><div class="dots">${dots}</div>` +
        `<p style="margin:6px 0">${esc(w.message)}</p>` +
        `<div class="facts"><div>Accuracy<b>${w.baseline ? '–' : w.correct + '/' + w.n}</b></div>` +
        `<div>Difficulty-weighted miss rate<b>${Math.round(w.weighted_miss * 100)}%</b></div>` +
        `<div>Misses in last 5<b>${w.last5}</b></div><div>Prediction confidence<b>${w.confidence}</b></div></div>` +
        `<p class="legend">Score = 60% weighted miss rate + 25% recurrence + 15% worsening trend. Recent answers count more; missing an easy question counts more than a hard one.</p>` +
        `<button class="btn" id="pr" type="button">Practice ${esc(w.name)}</button>`;
      $('pr').onclick = () => { assess = null; q = null; go('practice'); };
    } catch (e) { $('why').textContent = e.message; }
  }

  async function refresh() {
    D = await api('/api/dashboard');
    renderStats(); renderBoard(); renderTree(); renderPlan();
  }

  // ------------------------------------------------------------------- quiz
  async function loadQuestion() {
    const T = topicIndex();
    try {
      q = await api('/api/question?' + (assess ? 'level=' + encodeURIComponent(assess) : 'topic=' + encodeURIComponent(sel)));
    } catch (e) { $('quiz').textContent = e.message; return; }
    if (assess) { sel = q.topic; loadWhy(); renderBoard(); }
    renderQuestion(T);
  }

  function renderQuestion(T) {
    T = T || topicIndex();
    const t = T[sel];
    $('chips').innerHTML = '';
    const chip = (text) => { const s = document.createElement('span'); s.className = 'chip'; s.textContent = text; $('chips').appendChild(s); };
    chip(assess ? '🏅 Proficiency Assessment' : t.levelName);
    chip(t.glyph + ' ' + t.name);
    const wk = document.createElement('button');
    wk.className = 'btn ghost'; wk.type = 'button'; wk.textContent = 'Switch to weakest topic';
    wk.onclick = () => {
      const weakest = allTopics().reduce((a, b) => (b.risk > a.risk ? b : a));
      selectTopic(weakest.key); loadQuestion();
    };
    $('chips').appendChild(wk);
    $('focus').textContent = 'Pick any sub-topic from the sidebar. Questions match your current risk and rotate through the whole topic.';

    const box = $('quiz');
    box.innerHTML = '';
    const p = document.createElement('p');
    p.style.margin = '10px 0 0';
    const b = document.createElement('b'); b.textContent = q.text; p.appendChild(b);
    const sub = document.createElement('div'); sub.className = 'sub'; sub.textContent = 'Difficulty ' + q.difficulty + ' of 3';
    const opts = document.createElement('div'); opts.className = 'opts';
    q.options.forEach((text, i) => {
      const btn = document.createElement('button');
      btn.className = 'opt'; btn.type = 'button'; btn.dataset.i = i; btn.textContent = text;
      btn.onclick = () => answer(i);
      opts.appendChild(btn);
    });
    const fb = document.createElement('div'); fb.id = 'fb';
    box.append(p, sub, opts, fb);
  }

  async function answer(i) {
    const buttons = [...document.querySelectorAll('.opt')];
    buttons.forEach((b) => { b.disabled = true; });
    let r;
    try {
      r = await api('/api/answer', { method: 'POST', body: { qid: q.id, choice: i } });
    } catch (e) {
      $('fb').textContent = e.message;
      buttons.forEach((b) => { b.disabled = false; });
      return;
    }
    buttons.forEach((b, k) => {
      if (k === r.answer) b.classList.add('right');
      else if (k === i) b.classList.add('wrong');
    });
    const before = Math.round(r.before * 100), after = Math.round(r.after * 100);
    const fb = $('fb');
    fb.innerHTML =
      `<div class="delta ${r.correct ? 'good' : 'bad'}"><b>${r.correct ? '✓ Correct!' : '✗ Not quite.'}</b> Risk for ${esc(topicIndex()[r.topic].name)}: ` +
      `${before}% to <b>${after}%</b> (${r.delta > 0 ? '+' : ''}${r.delta} pts, now ${TIER_LABEL[r.tier].toLowerCase()}).</div>` +
      `<div id="fbBtns" style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap"><button class="btn" id="nx" type="button">Next question</button>` +
      `<button class="btn ghost" id="wk2" type="button">Go to weakest topic</button>` +
      (D.ai_enabled ? '<button class="btn ghost" id="ex" type="button">Explain with AI</button>' : '') + '</div><div id="aiText" class="sub" style="margin-top:10px"></div>';
    $('nx').onclick = () => { q = null; loadQuestion(); };
    $('wk2').onclick = () => { assess = null; const wkn = allTopics().reduce((a, b) => (b.risk > a.risk ? b : a)); selectTopic(wkn.key); loadQuestion(); };
    if ($('ex')) $('ex').onclick = async () => {
      $('aiText').textContent = 'Thinking…';
      try { $('aiText').textContent = (await api('/api/explain', { method: 'POST', body: { qid: q.id, choice: i } })).explanation; }
      catch (e) { $('aiText').textContent = e.message; }
    };
    await refresh();
    loadWhy();
  }

  // -------------------------------------------------------------------- auth
  function setMode(m) {
    mode = m;
    $('t-up').setAttribute('aria-selected', String(m === 'up'));
    $('t-in').setAttribute('aria-selected', String(m === 'in'));
    $('l-name').hidden = $('l-pw2').hidden = m === 'in';
    $('go').textContent = m === 'up' ? 'Create account' : 'Log in';
    $('pw').autocomplete = m === 'up' ? 'new-password' : 'current-password';
    $('err').textContent = '';
  }
  $('t-up').onclick = () => setMode('up');
  $('t-in').onclick = () => setMode('in');
  $('show').onchange = (e) => { $('pw').type = $('pw2').type = e.target.checked ? 'text' : 'password'; };

  $('af').onsubmit = async (e) => {
    e.preventDefault();
    const err = (m) => { $('err').textContent = m; };
    const name = $('name').value.trim(), email = $('email').value.trim().toLowerCase(), pw = $('pw').value;
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return err('Enter a valid email address, like name@college.edu.');
    if (mode === 'up') {
      if (!name) return err('Enter your name.');
      if (pw.length < 8) return err('Use a password with at least 8 characters.');
      if (pw !== $('pw2').value) return err('The two passwords do not match.');
    }
    $('go').disabled = true;
    try {
      await api(mode === 'up' ? '/api/signup' : '/api/login', { method: 'POST', body: { name, email, password: pw } });
      await enter();
    } catch (x) { err(x.message); }
    $('go').disabled = false;
  };

  $('demo').onclick = async () => {
    try { await api('/api/demo', { method: 'POST' }); await enter(); } catch (x) { $('err').textContent = x.message; }
  };

  $('out').onclick = async () => {
    try { await api('/api/logout', { method: 'POST' }); } catch (e) { /* already signed out */ }
    D = null; sel = null; q = null; assess = null;
    ['app', 'bar', 'side', 'xpc', 'menu'].forEach((k) => { $(k).hidden = true; });
    $('auth').hidden = false;
    $('af').reset();
    setMode('up');
    window.scrollTo(0, 0);
  };

  async function enter() {
    D = await api('/api/dashboard');
    D.levels.forEach((l, i) => { if (openG[l.id] === undefined) openG[l.id] = i === 0; });
    sel = D.stats.focus; assess = null; q = null;
    $('who').textContent = D.user.name;
    $('av').textContent = (D.user.name.trim()[0] || '?').toUpperCase();
    $('bar').title = D.user.demo ? 'Demo account' : 'Signed in as ' + D.user.email;
    $('auth').hidden = true;
    ['bar', 'side', 'app', 'menu'].forEach((k) => { $(k).hidden = false; });
    renderStats(); renderBoard(); renderPlan();
    await loadWhy();
    go('home');
  }

  // -------------------------------------------------------------------- boot
  document.querySelectorAll('.nv[data-v]').forEach((b) => { b.onclick = () => go(b.dataset.v); });
  setMode('up');
  api('/api/me').then(enter).catch(() => { /* not signed in: show the auth card */ });
})();
