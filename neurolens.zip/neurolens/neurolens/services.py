"""Business logic: risk per topic, dashboard data, question flow."""
from __future__ import annotations

import json
import os
import random
from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List, Optional

from . import db
from .questions import DATA_DIR, QuestionBank
from .risk_model import MEDIUM, MissModel, TopicRisk, compute_topic_risk, tier

MINUTES_PER_ANSWER = 1.5


class Services:
    def __init__(self, config: dict):
        with open(os.path.join(DATA_DIR, "curriculum.json"), encoding="utf-8") as f:
            self.levels: List[dict] = json.load(f)["levels"]
        self.topics: Dict[str, dict] = {}
        for lv in self.levels:
            for t in lv["topics"]:
                self.topics[t["key"]] = {**t, "level": lv["id"]}
        self.bank = QuestionBank()
        self.engine = config.get("RISK_ENGINE", "heuristic")
        self.miss_model = MissModel(config.get("MODEL_PATH")) if self.engine == "ml" else None
        if self.engine == "ml" and not self.miss_model.available:
            print("WARNING: RISK_ENGINE=ml but no model found. Run `python train_model.py`. Using heuristic.")
        with open(os.path.join(DATA_DIR, "demo_seed.json"), encoding="utf-8") as f:
            self.demo_seed = json.load(f)

    # -------------------------------------------------------------- helpers
    @staticmethod
    def _real(rows):
        return [r for r in rows if r["qid"]]

    def attendance(self, user, rows) -> float:
        """Demo users have a fixed base; real users start at 0 and grow with practice."""
        if user["base_attendance"] is not None:
            return float(user["base_attendance"])
        days = {r["created_at"][:10] for r in self._real(rows)}
        if not days:
            return 0.0
        joined = datetime.fromisoformat(user["created_at"]).date()
        span = max(1, (datetime.now(timezone.utc).date() - joined).days + 1)
        return round(100 * min(len(days), span) / span)

    def hours(self, user, rows) -> float:
        return float(user["base_hours"]) + len(self._real(rows)) * MINUTES_PER_ANSWER / 60

    def risks(self, rows, attendance) -> Dict[str, TopicRisk]:
        by_topic = defaultdict(list)
        for r in rows:
            by_topic[r["topic"]].append((r["difficulty"], r["correct"]))
        out = {}
        for key in self.topics:
            tr = compute_topic_risk(by_topic.get(key, []), attendance)
            if self.miss_model and self.miss_model.available and not tr.baseline:
                p = self.miss_model.predict_miss(by_topic[key])
                tr.risk = 0.5 * tr.risk + 0.5 * p
            out[key] = tr
        return out

    @staticmethod
    def message(tr: TopicRisk) -> str:
        if tr.baseline:
            return ("No history yet, so this is a neutral baseline. "
                    "Answer a few questions to replace it with a real estimate.")
        if tr.last5 >= 3:
            return f"Recurring weakness: {tr.last5} of the last {min(5, tr.n)} answers were wrong."
        if tr.risk < MEDIUM:
            return "Looking solid. A short review now and then is enough."
        return "Some misses, but not yet a stable pattern. A short drill will settle it."

    @staticmethod
    def _confidence_label(c: float) -> str:
        return "high" if c > 0.6 else "medium" if c > 0.35 else "low"

    # ------------------------------------------------------------ dashboard
    def dashboard(self, user) -> dict:
        rows = db.user_attempts(user["id"])
        att = self.attendance(user, rows)
        risks = self.risks(rows, att)

        n = len(rows)
        correct = sum(r["correct"] for r in rows)
        xp = sum(5 + 5 * r["difficulty"] for r in rows if r["correct"])
        mastered = sum(1 for tr in risks.values() if tr.mastered)

        best = run = 0
        for r in self._real(rows):
            run = run + 1 if r["correct"] else 0
            best = max(best, run)

        focus = max(risks, key=lambda k: risks[k].risk)  # first of equals = curriculum order
        diff = []
        for d in (1, 2, 3):
            z = [r for r in rows if r["difficulty"] == d]
            c = sum(r["correct"] for r in z)
            diff.append({"d": d, "n": len(z), "pct": round(100 * c / len(z)) if z else 0})
        hard_hits = sum(1 for r in rows if r["difficulty"] == 3 and r["correct"])

        levels = []
        for lv in self.levels:
            topics = []
            for t in lv["topics"]:
                tr = risks[t["key"]]
                topics.append({
                    **t, "risk": round(tr.risk, 4), "tier": tr.tier, "n": tr.n,
                    "confidence": round(tr.confidence, 3), "last5": tr.last5,
                    "missed_easy": tr.missed_easy,
                })
            levels.append({"id": lv["id"], "name": lv["name"], "icon": lv["icon"], "topics": topics})

        from . import ai_helper  # local import keeps module load light

        return {
            "user": {"name": user["name"], "email": "" if user["is_demo"] else user["email"],
                     "demo": bool(user["is_demo"])},
            "stats": {
                "xp": xp, "level": 1 + xp // 100, "accuracy": round(100 * correct / n) if n else 0,
                "attempts": n, "best_streak": best, "mastered": mastered,
                "total_topics": len(self.topics), "focus": focus,
            },
            "habits": {"attendance": att, "hours": round(self.hours(user, rows), 4)},
            "difficulty": diff,
            "badges": [
                {"icon": "🌱", "title": "First steps", "desc": "Answer a question", "earned": n >= 1},
                {"icon": "⚡", "title": "On a roll", "desc": "5 correct in a row", "earned": best >= 5},
                {"icon": "💪", "title": "Hard hitter", "desc": "2 hard questions right", "earned": hard_hits >= 2},
                {"icon": "🎓", "title": "Topic tamer", "desc": "Master any topic", "earned": mastered >= 1},
            ],
            "levels": levels,
            "ai_enabled": ai_helper.available(),
        }

    def topic_detail(self, user, key: str) -> Optional[dict]:
        if key not in self.topics:
            return None
        rows = db.user_attempts(user["id"])
        tr = self.risks(rows, self.attendance(user, rows))[key]
        attempts = [[r["difficulty"], r["correct"]] for r in rows if r["topic"] == key]
        return {
            "key": key, "name": self.topics[key]["name"], "risk": round(tr.risk, 4), "tier": tr.tier,
            "attempts": attempts, "n": tr.n, "correct": tr.correct,
            "weighted_miss": round(tr.weighted_miss, 4), "last5": tr.last5,
            "confidence": self._confidence_label(tr.confidence), "baseline": tr.baseline,
            "message": self.message(tr),
        }

    # ------------------------------------------------------------- questions
    def next_question(self, user, topic: Optional[str] = None, level: Optional[str] = None,
                      rng: Optional[random.Random] = None) -> Optional[dict]:
        rng = rng or random
        rows = db.user_attempts(user["id"])
        risks = self.risks(rows, self.attendance(user, rows))

        if level:  # proficiency assessment: always the weakest topic in the level
            keys = [k for k, t in self.topics.items() if t["level"] == level]
            if not keys:
                return None
            keys.sort(key=lambda k: (-risks[k].risk, rng.random()))
            topic = keys[0]
        if topic not in self.topics:
            return None

        answered = [r["qid"] for r in rows if r["topic"] == topic and r["qid"]]
        seen = self.bank.current_cycle_seen(topic, answered)
        q = self.bank.pick(topic, risks[topic].risk, seen, answered[-1] if answered else None, rng)
        return self.bank.public(q) if q else None

    def record_answer(self, user, qid: str, choice: int) -> Optional[dict]:
        q = self.bank.by_id.get(qid)
        if not q:
            return None
        rows = db.user_attempts(user["id"])
        att = self.attendance(user, rows)
        before = self.risks(rows, att)[q["topic"]].risk
        ok = choice == q["answer"]
        db.add_attempt(user["id"], q["topic"], qid, q["difficulty"], ok)
        rows = db.user_attempts(user["id"])
        after = self.risks(rows, self.attendance(user, rows))[q["topic"]].risk
        return {
            "correct": ok, "answer": q["answer"], "topic": q["topic"],
            "before": round(before, 4), "after": round(after, 4),
            "delta": round((after - before) * 100), "tier": tier(after),
        }

    # ------------------------------------------------------------------ demo
    def create_demo_user(self, token: str) -> int:
        db.delete_old_demo_users()
        seed = self.demo_seed
        uid = db.create_user(
            seed["name"], f"demo-{token}@neurolens.local", "!",  # "!" can never match a password hash
            base_attendance=seed["attendance"], base_hours=seed["hours"], is_demo=True,
        )
        for topic, history in seed["history"].items():
            for d, c in history:
                db.add_attempt(uid, topic, None, d, c)
        return uid
