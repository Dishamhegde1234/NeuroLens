"""NeuroLens: AI-powered learning difficulty predictor (C programming)."""
from __future__ import annotations

from flask import Flask, render_template

from . import db
from .api import bp as api_bp
from .config import load_config
from .services import Services


def create_app(test_config: dict | None = None) -> Flask:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:  # python-dotenv is optional
        pass

    app = Flask(__name__)
    app.config.update(load_config(quiet=bool(test_config and "SECRET_KEY" in test_config)))
    if test_config:
        app.config.update(test_config)

    app.extensions["neurolens"] = Services(app.config)
    app.teardown_appcontext(db.close_db)
    app.register_blueprint(api_bp)

    with app.app_context():
        db.init_db()

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        if resp.mimetype == "application/json":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.cli.command("init-db")
    def init_db_command():
        """Create the database tables."""
        db.init_db()
        print("Database ready at", app.config["DATABASE"])

    return app
