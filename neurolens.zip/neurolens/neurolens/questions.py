"""Question bank and adaptive question picking."""
from __future__ import annotations

import json
import os
import random
from typing import Dict, Iterable, List, Optional, Set

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


class QuestionBank:
    def __init__(self, path: Optional[str] = None):
        path = path or os.path.join(DATA_DIR, "questions.json")
        with open(path, encoding="utf-8") as f:
            self.questions: List[dict] = json.load(f)
        self.by_id: Dict[str, dict] = {q["id"]: q for q in self.questions}
        self.by_topic: Dict[str, List[dict]] = {}
        for q in self.questions:
            self.by_topic.setdefault(q["topic"], []).append(q)

    @staticmethod
    def public(q: dict) -> dict:
        """What the browser may see: never the answer."""
        return {k: q[k] for k in ("id", "topic", "difficulty", "text", "options")}

    def current_cycle_seen(self, topic: str, answered_ids: Iterable[str]) -> Set[str]:
        """Question ids already used in the current pass through this topic.

        Once every question in a topic has been asked, the pass restarts, so
        nothing repeats until the whole topic has been covered.
        """
        all_ids = {q["id"] for q in self.by_topic.get(topic, [])}
        seen: Set[str] = set()
        for qid in answered_ids:
            if qid in all_ids:
                seen.add(qid)
                if seen == all_ids:
                    seen = set()
        return seen

    def pick(
        self,
        topic: str,
        risk: float,
        seen: Set[str],
        last_id: Optional[str] = None,
        rng: Optional[random.Random] = None,
    ) -> Optional[dict]:
        rng = rng or random
        pool = [q for q in self.by_topic.get(topic, []) if q["id"] not in seen]
        if not pool:
            pool = [q for q in self.by_topic.get(topic, []) if q["id"] != last_id]
        if not pool:
            return None
        # Weaker topics start easier; stronger topics get harder questions.
        target = 1.5 if risk >= 0.55 else 2.0 if risk >= 0.38 else 2.5
        pool.sort(key=lambda q: abs(q["difficulty"] - target) + (rng.random() - 0.5) * 0.9)
        return pool[0]
