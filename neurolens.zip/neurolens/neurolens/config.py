"""Configuration, read from environment variables (see .env.example)."""
import os
import secrets
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def load_config(quiet: bool = False) -> dict:
    secret = os.environ.get("SECRET_KEY")
    if not secret:
        # Fine for local development, but sessions reset on every restart.
        # Set SECRET_KEY in .env for anything shared or deployed.
        secret = secrets.token_hex(32)
        if not quiet:
            print("WARNING: SECRET_KEY is not set; using a temporary key.")
    return {
        "SECRET_KEY": secret,
        "DATABASE": os.environ.get(
            "DATABASE_PATH", os.path.join(BASE_DIR, "instance", "neurolens.db")
        ),
        # "heuristic" (default, fully explainable) or "ml" (blend with the trained model)
        "RISK_ENGINE": os.environ.get("RISK_ENGINE", "heuristic").lower(),
        "MODEL_PATH": os.environ.get(
            "MODEL_PATH", os.path.join(BASE_DIR, "models", "miss_model.joblib")
        ),
        "SESSION_COOKIE_HTTPONLY": True,
        "SESSION_COOKIE_SAMESITE": "Lax",
        "SESSION_COOKIE_SECURE": os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",
        "PERMANENT_SESSION_LIFETIME": timedelta(days=14),
        "MAX_CONTENT_LENGTH": 64 * 1024,
    }
