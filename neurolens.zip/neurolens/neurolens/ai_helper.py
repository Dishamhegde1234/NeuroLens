"""Optional AI explanations via Gemini or OpenAI (REST, no SDK needed).

Set GEMINI_API_KEY or OPENAI_API_KEY in .env. Model names are configurable
(GEMINI_MODEL / OPENAI_MODEL) because providers retire models over time, so
check their docs for the current names.
"""
from __future__ import annotations

import os
from typing import Optional

import requests

TIMEOUT = 20


class AIError(RuntimeError):
    pass


def provider() -> Optional[str]:
    if os.environ.get("GEMINI_API_KEY"):
        return "gemini"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    return None


def available() -> bool:
    return provider() is not None


def build_prompt(topic: str, question: dict, choice: int) -> str:
    opts = "\n".join(f"{chr(65 + i)}. {o}" for i, o in enumerate(question["options"]))
    correct = question["answer"]
    verdict = "correct" if choice == correct else f"wrong (they chose {chr(65 + choice)})"
    return (
        "You are a friendly C programming tutor. In at most 80 words and plain text "
        "(no markdown), explain why the correct answer is right"
        + (", and why the student's choice is wrong" if choice != correct else "")
        + ". Add one short tip to remember it.\n\n"
        f"Topic: {topic}\nQuestion: {question['text']}\n{opts}\n"
        f"Correct answer: {chr(65 + correct)}\nThe student's answer was {verdict}."
    )


def explain(topic: str, question: dict, choice: int) -> str:
    which = provider()
    if not which:
        raise AIError("No AI provider configured.")
    prompt = build_prompt(topic, question, choice)
    try:
        if which == "gemini":
            model = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")
            resp = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"], "Content-Type": "application/json"},
                json={"contents": [{"parts": [{"text": prompt}]}],
                      "generationConfig": {"temperature": 0.3, "maxOutputTokens": 300}},
                timeout=TIMEOUT,
            )
            resp.raise_for_status()
            return resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
        model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
            json={"model": model, "temperature": 0.3, "max_tokens": 300,
                  "messages": [{"role": "user", "content": prompt}]},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
    except (requests.RequestException, KeyError, IndexError, ValueError) as exc:
        raise AIError("The AI service could not answer right now.") from exc
