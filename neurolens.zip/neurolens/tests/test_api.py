import os
import random
import tempfile
import unittest

from neurolens import create_app, db


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({
            "TESTING": True, "SECRET_KEY": "test",
            "DATABASE": os.path.join(self.tmp.name, "test.db"),
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    # helpers
    def signup(self, client=None, email="eshani@example.com", password="correct horse"):
        return (client or self.client).post("/api/signup", json={"name": "Eshani", "email": email, "password": password})

    def bank(self):
        return self.app.extensions["neurolens"].bank

    # --- auth
    def test_requires_login(self):
        for path in ("/api/dashboard", "/api/question?topic=IC", "/api/topic/IC"):
            self.assertEqual(self.client.get(path).status_code, 401, path)

    def test_signup_validation(self):
        r = self.client.post("/api/signup", json={"name": "", "email": "x@y.zz", "password": "longenough"})
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/signup", json={"name": "A", "email": "not-an-email", "password": "longenough"})
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/signup", json={"name": "A", "email": "a@b.co", "password": "short"})
        self.assertEqual(r.status_code, 400)

    def test_signup_login_logout_and_duplicate(self):
        self.assertEqual(self.signup().status_code, 201)
        self.assertEqual(self.client.get("/api/me").status_code, 200)
        self.client.post("/api/logout")
        self.assertEqual(self.client.get("/api/me").status_code, 401)
        self.assertEqual(self.signup().status_code, 409)
        ok = self.client.post("/api/login", json={"email": "eshani@example.com", "password": "correct horse"})
        self.assertEqual(ok.status_code, 200)
        self.client.post("/api/logout")
        bad = self.client.post("/api/login", json={"email": "eshani@example.com", "password": "wrong password"})
        self.assertEqual(bad.status_code, 401)

    def test_password_is_hashed(self):
        self.signup()
        with self.app.app_context():
            row = db.get_user_by_email("eshani@example.com")
            self.assertNotIn("correct horse", row["password_hash"])

    def test_login_throttle(self):
        self.signup()
        self.client.post("/api/logout")
        codes = [self.client.post("/api/login", json={"email": "eshani@example.com", "password": "nope nope"}).status_code
                 for _ in range(7)]
        self.assertEqual(codes[:5], [401] * 5)
        self.assertEqual(codes[-1], 429)

    # --- new user starts at zero
    def test_new_user_starts_at_zero(self):
        self.signup()
        d = self.client.get("/api/dashboard").get_json()
        self.assertEqual(d["habits"], {"attendance": 0.0, "hours": 0.0})
        self.assertEqual(d["stats"]["attempts"], 0)
        self.assertEqual(d["stats"]["xp"], 0)
        self.assertEqual(sum(len(l["topics"]) for l in d["levels"]), 46)
        self.assertTrue(all(t["n"] == 0 for l in d["levels"] for t in l["topics"]))

    # --- questions
    def test_question_does_not_leak_answer(self):
        self.signup()
        q = self.client.get("/api/question?topic=PI").get_json()
        self.assertNotIn("answer", q)
        self.assertEqual(len(q["options"]), 4)

    def test_answer_flow_updates_risk_habits_and_xp(self):
        self.signup()
        q = self.client.get("/api/question?topic=IC").get_json()
        right = self.bank().by_id[q["id"]]["answer"]
        r = self.client.post("/api/answer", json={"qid": q["id"], "choice": right}).get_json()
        self.assertTrue(r["correct"])
        self.assertLess(r["after"], r["before"])
        d = self.client.get("/api/dashboard").get_json()
        self.assertEqual(d["stats"]["attempts"], 1)
        self.assertGreater(d["stats"]["xp"], 0)
        self.assertEqual(d["habits"]["attendance"], 100)
        self.assertGreater(d["habits"]["hours"], 0)

    def test_wrong_answer_raises_risk(self):
        self.signup()
        q = self.client.get("/api/question?topic=IC").get_json()
        wrong = (self.bank().by_id[q["id"]]["answer"] + 1) % 4
        r = self.client.post("/api/answer", json={"qid": q["id"], "choice": wrong}).get_json()
        self.assertFalse(r["correct"])
        self.assertGreater(r["after"], r["before"])

    def test_answer_validation(self):
        self.signup()
        for body in ({}, {"qid": "IC-01", "choice": 9}, {"qid": "IC-01", "choice": True}, {"qid": 5, "choice": 1}):
            self.assertEqual(self.client.post("/api/answer", json=body).status_code, 400)
        self.assertEqual(self.client.post("/api/answer", json={"qid": "ZZ-99", "choice": 1}).status_code, 404)

    def test_no_repeats_until_topic_is_exhausted(self):
        self.signup()
        topic = "IC"
        total = len(self.bank().by_topic[topic])
        seen = []
        for _ in range(total):
            q = self.client.get(f"/api/question?topic={topic}").get_json()
            seen.append(q["id"])
            self.client.post("/api/answer", json={"qid": q["id"], "choice": 0})
        self.assertEqual(len(set(seen)), total)
        nxt = self.client.get(f"/api/question?topic={topic}").get_json()
        self.assertNotEqual(nxt["id"], seen[-1])  # a new pass starts, but never the same question twice in a row

    def test_assessment_picks_weakest_topic_in_level(self):
        self.signup()
        for _ in range(3):  # make Operators clearly weak
            q = self.client.get("/api/question?topic=OP").get_json()
            wrong = (self.bank().by_id[q["id"]]["answer"] + 1) % 4
            self.client.post("/api/answer", json={"qid": q["id"], "choice": wrong})
        q = self.client.get("/api/question?level=L1").get_json()
        self.assertEqual(q["topic"], "OP")

    # --- users are isolated
    def test_users_are_isolated(self):
        self.signup()
        q = self.client.get("/api/question?topic=IC").get_json()
        self.client.post("/api/answer", json={"qid": q["id"], "choice": 0})
        other = self.app.test_client()
        self.signup(other, email="other@example.com")
        self.assertEqual(other.get("/api/dashboard").get_json()["stats"]["attempts"], 0)

    # --- demo + misc
    def test_demo_account_has_history_and_fixed_habits(self):
        self.assertEqual(self.client.post("/api/demo").status_code, 200)
        d = self.client.get("/api/dashboard").get_json()
        self.assertTrue(d["user"]["demo"])
        self.assertEqual(d["habits"]["attendance"], 82)
        self.assertGreater(d["stats"]["attempts"], 20)

    def test_demo_user_cannot_log_in_with_password(self):
        self.client.post("/api/demo")
        self.client.post("/api/logout")
        with self.app.app_context():
            email = db.get_db().execute("SELECT email FROM users WHERE is_demo=1").fetchone()["email"]
        r = self.client.post("/api/login", json={"email": email, "password": "!"})
        self.assertEqual(r.status_code, 401)

    def test_explain_without_ai_key_is_503(self):
        for k in ("GEMINI_API_KEY", "OPENAI_API_KEY"):
            os.environ.pop(k, None)
        self.signup()
        r = self.client.post("/api/explain", json={"qid": "IC-01", "choice": 0})
        self.assertEqual(r.status_code, 503)

    def test_index_and_health(self):
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/healthz").get_json(), {"status": "ok"})


class QuestionBankTests(unittest.TestCase):
    def test_bank_is_well_formed(self):
        app = create_app({"TESTING": True, "SECRET_KEY": "x", "DATABASE": ":memory:"})
        bank = app.extensions["neurolens"].bank
        topics = app.extensions["neurolens"].topics
        self.assertEqual(len(bank.questions), 236)
        for q in bank.questions:
            self.assertIn(q["topic"], topics)
            self.assertEqual(len(q["options"]), 4)
            self.assertEqual(len(set(q["options"])), 4, q["id"])
            self.assertIn(q["answer"], range(4))
            self.assertIn(q["difficulty"], (1, 2, 3))
        for key in topics:
            self.assertGreaterEqual(len(bank.by_topic[key]), 3, key)

    def test_answer_positions_are_varied(self):
        app = create_app({"TESTING": True, "SECRET_KEY": "x", "DATABASE": ":memory:"})
        positions = {q["answer"] for q in app.extensions["neurolens"].bank.questions}
        self.assertEqual(positions, {0, 1, 2, 3})


if __name__ == "__main__":
    unittest.main()
