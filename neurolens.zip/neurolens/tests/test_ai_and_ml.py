import os
import tempfile
import unittest
from unittest import mock

import requests

from neurolens import ai_helper, create_app

Q = {"text": "What is 7 / 2 in C when both are int?", "options": ["3.5", "3", "4", "2"], "answer": 1}


class FakeResponse:
    def __init__(self, payload, ok=True):
        self.payload, self.ok = payload, ok

    def raise_for_status(self):
        if not self.ok:
            raise requests.HTTPError("boom")

    def json(self):
        return self.payload


class AiHelperTests(unittest.TestCase):
    def setUp(self):
        self._env = dict(os.environ)
        for k in ("GEMINI_API_KEY", "OPENAI_API_KEY"):
            os.environ.pop(k, None)

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._env)

    def test_no_keys_means_unavailable(self):
        self.assertFalse(ai_helper.available())
        with self.assertRaises(ai_helper.AIError):
            ai_helper.explain("Operators", Q, 0)

    def test_prompt_mentions_wrong_choice_only_when_wrong(self):
        self.assertIn("why the student's choice is wrong", ai_helper.build_prompt("T", Q, 0))
        self.assertNotIn("why the student's choice is wrong", ai_helper.build_prompt("T", Q, 1))

    def test_gemini_parsing_and_key_in_header(self):
        os.environ["GEMINI_API_KEY"] = "k"
        payload = {"candidates": [{"content": {"parts": [{"text": " Integer division drops the fraction. "}]}}]}
        with mock.patch("requests.post", return_value=FakeResponse(payload)) as post:
            out = ai_helper.explain("Operators", Q, 0)
        self.assertEqual(out, "Integer division drops the fraction.")
        self.assertEqual(post.call_args.kwargs["headers"]["x-goog-api-key"], "k")
        self.assertNotIn("key=", post.call_args.args[0])

    def test_openai_parsing(self):
        os.environ["OPENAI_API_KEY"] = "k"
        payload = {"choices": [{"message": {"content": "Because both are ints."}}]}
        with mock.patch("requests.post", return_value=FakeResponse(payload)):
            self.assertEqual(ai_helper.explain("Operators", Q, 1), "Because both are ints.")

    def test_provider_failure_becomes_ai_error(self):
        os.environ["OPENAI_API_KEY"] = "k"
        with mock.patch("requests.post", return_value=FakeResponse({}, ok=False)):
            with self.assertRaises(ai_helper.AIError):
                ai_helper.explain("Operators", Q, 1)
        with mock.patch("requests.post", return_value=FakeResponse({"unexpected": 1})):
            with self.assertRaises(ai_helper.AIError):
                ai_helper.explain("Operators", Q, 1)


class MlEngineTests(unittest.TestCase):
    def test_ml_engine_falls_back_when_model_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app({"TESTING": True, "SECRET_KEY": "x", "RISK_ENGINE": "ml",
                              "MODEL_PATH": os.path.join(tmp, "missing.joblib"),
                              "DATABASE": os.path.join(tmp, "t.db")})
            c = app.test_client()
            c.post("/api/demo")
            self.assertEqual(c.get("/api/dashboard").status_code, 200)

    @unittest.skipUnless(os.path.exists(os.path.join("models", "miss_model.joblib")),
                         "run `python train_model.py` first")
    def test_ml_engine_blends_model_prediction(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = {"TESTING": True, "SECRET_KEY": "x", "DATABASE": os.path.join(tmp, "t.db")}
            heuristic = create_app({**cfg, "RISK_ENGINE": "heuristic"}).test_client()
            ml = create_app({**cfg, "DATABASE": os.path.join(tmp, "m.db"), "RISK_ENGINE": "ml",
                             "MODEL_PATH": os.path.join("models", "miss_model.joblib")}).test_client()
            risks = []
            for c in (heuristic, ml):
                c.post("/api/demo")
                d = c.get("/api/dashboard").get_json()
                risks.append({t["key"]: t["risk"] for l in d["levels"] for t in l["topics"]})
            self.assertNotEqual(risks[0]["OP"], risks[1]["OP"])
            self.assertTrue(all(0 <= v <= 1 for v in risks[1].values()))


if __name__ == "__main__":
    unittest.main()
