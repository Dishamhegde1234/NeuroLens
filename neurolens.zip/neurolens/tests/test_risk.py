import unittest

from neurolens.risk_model import (HIGH, MEDIUM, compute_topic_risk, features,
                                  tier)


class RiskModelTests(unittest.TestCase):
    def test_no_history_is_neutral_baseline(self):
        tr = compute_topic_risk([])
        self.assertTrue(tr.baseline)
        self.assertEqual(tr.risk, 0.4)
        self.assertEqual(tr.confidence, 0)

    def test_one_wrong_answer_does_not_decide(self):
        tr = compute_topic_risk([(2, 0)])
        self.assertLess(tr.risk, HIGH)
        self.assertLess(tr.confidence, 0.25)

    def test_recent_misses_raise_risk(self):
        improving = compute_topic_risk([(2, 0), (2, 0), (2, 1), (2, 1), (2, 1)])
        worsening = compute_topic_risk([(2, 1), (2, 1), (2, 0), (2, 0), (2, 0)])
        self.assertGreater(worsening.risk, improving.risk)
        self.assertGreaterEqual(worsening.last5, 3)

    def test_missing_easy_is_worse_than_missing_hard(self):
        easy_miss = compute_topic_risk([(1, 0), (3, 1), (2, 1)])
        hard_miss = compute_topic_risk([(1, 1), (3, 0), (2, 1)])
        self.assertGreater(easy_miss.risk, hard_miss.risk)

    def test_all_correct_becomes_low_and_mastered(self):
        tr = compute_topic_risk([(1, 1), (2, 1), (2, 1), (3, 1), (3, 1)])
        self.assertEqual(tier(tr.risk), "lo")
        self.assertTrue(tr.mastered)

    def test_low_attendance_adds_small_bump(self):
        a = compute_topic_risk([(2, 0), (2, 1)], attendance=90)
        b = compute_topic_risk([(2, 0), (2, 1)], attendance=60)
        self.assertAlmostEqual(b.risk - a.risk, 0.04, places=6)

    def test_risk_is_bounded(self):
        tr = compute_topic_risk([(1, 0)] * 20, attendance=10)
        self.assertLessEqual(tr.risk, 1.0)

    def test_feature_vector_length(self):
        self.assertEqual(len(features([(1, 1), (2, 0)])), 7)
        self.assertEqual(len(features([])), 7)

    def test_tier_thresholds(self):
        self.assertEqual(tier(HIGH), "hi")
        self.assertEqual(tier(MEDIUM), "mid")
        self.assertEqual(tier(MEDIUM - 0.01), "lo")


if __name__ == "__main__":
    unittest.main()
